#include "AEConfig.h"
#include "AE_EffectVers.h"

#ifndef AE_OS_WIN
    #include <AE_General.r>
#endif

resource 'PiPL' (16000) {
    {   /* array properties */
        Kind { AEEffect },
        Name { "RimLight" },
        Category { "Avaris" },
#ifdef AE_OS_WIN
    #ifdef AE_PROC_INTELx64
        CodeWin64X86 { "EffectMain" },
    #endif
#else
    #ifdef AE_OS_MAC
        CodeMacIntel64 { "EffectMain" },
    #endif
#endif
        AE_PiPL_Version { 2, 0 },
        AE_Effect_Spec_Version { PF_PLUG_IN_VERSION, PF_PLUG_IN_SUBVERS },
        AE_Effect_Version { 0x00010000 },
        AE_Effect_Info_Flags { 0 },
        AE_Effect_Global_OutFlags { PF_OutFlag_DEEP_COLOR_AWARE },
        AE_Effect_Global_OutFlags_2 {
            PF_OutFlag2_SUPPORTS_THREADED_RENDERING |
            PF_OutFlag2_AE13_5_THREADSAFE
        },
        AE_Effect_Match_Name { "Avaris RimLight" },
        AE_Reserved_Info { 0 }
    }
};
