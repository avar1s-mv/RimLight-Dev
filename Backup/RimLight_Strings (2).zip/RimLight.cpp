﻿#include "RimLight.h"

static inline A_u_char clamp255(int v)
{
    if (v < 0)   return 0;
    if (v > 255) return 255;
    return static_cast<A_u_char>(v);
}

static inline A_u_short clamp32768(int v)
{
    if (v < 0)     return 0;
    if (v > 32768) return 32768;
    return static_cast<A_u_short>(v);
}

// ─────────────────────────────────────────────────────────────────────────────
// About
// ─────────────────────────────────────────────────────────────────────────────

static PF_Err About(
    PF_InData* in_data,
    PF_OutData* out_data,
    PF_ParamDef* params[],
    PF_LayerDef* output)
{
    AEGP_SuiteHandler suites(in_data->pica_basicP);
    suites.ANSICallbacksSuite1()->sprintf(
        out_data->return_msg,
        "%s v%d.%d\r%s",
        STR(StrID_Name),
        MAJOR_VERSION,
        MINOR_VERSION,
        STR(StrID_Description));
    return PF_Err_NONE;
}

// ─────────────────────────────────────────────────────────────────────────────
// GlobalSetup
// ─────────────────────────────────────────────────────────────────────────────

static PF_Err GlobalSetup(
    PF_InData* in_data,
    PF_OutData* out_data,
    PF_ParamDef* params[],
    PF_LayerDef* output)
{
    out_data->my_version = 524289;

    out_data->out_flags =
        PF_OutFlag_DEEP_COLOR_AWARE |
        PF_OutFlag_SEND_UPDATE_PARAMS_UI;

    out_data->out_flags2 = 0;

    return PF_Err_NONE;
}

// ─────────────────────────────────────────────────────────────────────────────
// ParamsSetup
// ─────────────────────────────────────────────────────────────────────────────

static PF_Err ParamsSetup(
    PF_InData* in_data,
    PF_OutData* out_data,
    PF_ParamDef* params[],
    PF_LayerDef* output)
{
    PF_Err      err = PF_Err_NONE;
    PF_ParamDef def;

    AEFX_CLR_STRUCT(def);
    PF_ADD_COLOR(STR(StrID_RimColor_Param_Name), PF_MAX_CHAN8, PF_MAX_CHAN8, PF_MAX_CHAN8, RIM_COLOR);

    AEFX_CLR_STRUCT(def);
    PF_ADD_FLOAT_SLIDERX(STR(StrID_RimSize_Param_Name),
        RIM_SIZE_MIN, RIM_SIZE_MAX, RIM_SIZE_MIN, RIM_SIZE_MAX, RIM_SIZE_DFLT,
        PF_Precision_HUNDREDTHS, 0, 0, RIM_SIZE);

    AEFX_CLR_STRUCT(def);
    PF_ADD_FLOAT_SLIDERX(STR(StrID_RimOpacity_Param_Name),
        RIM_OPACITY_MIN, RIM_OPACITY_MAX, RIM_OPACITY_MIN, RIM_OPACITY_MAX, RIM_OPACITY_DFLT,
        PF_Precision_HUNDREDTHS, 0, 0, RIM_OPACITY);

    AEFX_CLR_STRUCT(def);
    PF_ADD_ANGLE(STR(StrID_RimAngle_Param_Name), RIM_ANGLE_DFLT, RIM_ANGLE);

    out_data->num_params = RIM_NUM_PARAMS;
    return err;
}

// ─────────────────────────────────────────────────────────────────────────────
// Rim Light Render — 8-bit
//
// Konsep: fill putih digeser ke arah cahaya, lalu di-alpha matte ke layer asli.
//
//   Angle = arah datangnya cahaya (default 180 = dari kiri).
//   Fill solid digeser sejauh Size pixel ke arah BERLAWANAN angle (menjauhi cahaya).
//   Fill di-clamp oleh alpha layer asli (hanya kelihatan di dalam alpha layer).
//   Hasilnya di-composite di DEPAN layer asli.
//
//   Per pixel (x, y):
//     1. origAlpha    = alpha layer asli di (x, y)
//     2. shiftedAlpha = alpha layer asli di (x - dx, y - dy)  ← geser menjauhi cahaya
//     3. invertedFill = 1 - shiftedAlpha                      ← rim kuat di tepi menghadap cahaya
//     4. mattedFill   = min(invertedFill, origAlpha)           ← fill di-clamp alpha asli
//     5. rimAlpha     = mattedFill * opacity
//     6. Composite: rimColor over layer asli, dengan rimAlpha
//     7. outAlpha     = origAlpha  (alpha tidak berubah, rim hanya di dalam layer)
// ─────────────────────────────────────────────────────────────────────────────

static PF_Err RimRender8(
    PF_InData* in_data,
    PF_LayerDef* src,
    PF_LayerDef* dst,
    const RimLightInfo& info)
{
    const A_long width = dst->width;
    const A_long height = dst->height;
    const A_long src_stride = src->rowbytes / sizeof(PF_Pixel8);
    const A_long dst_stride = dst->rowbytes / sizeof(PF_Pixel8);

    const PF_Pixel8* src_base = reinterpret_cast<const PF_Pixel8*>(src->data);
    PF_Pixel8* dst_base = reinterpret_cast<PF_Pixel8*>(dst->data);

    const double angle_rad = info.rim_angle * 3.14159265358979323846 / 180.0;
    const double dist = info.rim_size;
    const double opacity = info.rim_opacity / 100.0;

    // Arah geser fill: KE ARAH BERLAWANAN cahaya
    // Rim muncul di tepi yang MENGHADAP cahaya.
    // Kita sample alpha di (x - dx, y - dy): arah berlawanan dari sumber cahaya.
    // Jika piksel ada di tepi menghadap cahaya → posisi sample jatuh di luar layer → shiftedAlpha=0
    // → invertedFill=1 → rim penuh. Jika piksel di tengah → shiftedAlpha≈1 → rim=0. ✓
    //
    // AE angle convention: 0°=kanan, CCW positif.
    // Screen Y terbalik → dy negatif = gerak ke atas di buffer.
    const double dx = cos(angle_rad) * dist;
    const double dy = -sin(angle_rad) * dist;

    const double rimR_n = info.rim_color.red / 255.0;
    const double rimG_n = info.rim_color.green / 255.0;
    const double rimB_n = info.rim_color.blue / 255.0;

    for (A_long y = 0; y < height; ++y) {
        for (A_long x = 0; x < width; ++x) {
            const PF_Pixel8& sp = src_base[y * src_stride + x];
            PF_Pixel8& dp = dst_base[y * dst_stride + x];

            const double origAlpha = sp.alpha / 255.0;

            // Sample ke arah BERLAWANAN cahaya (negasi dx/dy)
            const double sx_f = (double)x - dx;
            const double sy_f = (double)y - dy;

            // Bilinear interpolation
            double shiftedAlpha = 0.0;
            {
                const int sx0 = (int)floor(sx_f);
                const int sy0 = (int)floor(sy_f);
                const int sx1 = sx0 + 1;
                const int sy1 = sy0 + 1;
                const double fx = sx_f - (double)sx0;
                const double fy = sy_f - (double)sy0;

                auto safeA = [&](int px, int py) -> double {
                    // Return 0.0 jika out-of-bounds: piksel di luar canvas memang tidak ada.
                    // Clamp ke border justru bikin shiftedAlpha ≠ 0 di tepi canvas → flicker.
                    if (px < 0 || px >= width || py < 0 || py >= height) return 0.0;
                    return src_base[py * src_stride + px].alpha / 255.0;
                    };

                shiftedAlpha =
                    safeA(sx0, sy0) * (1.0 - fx) * (1.0 - fy) +
                    safeA(sx1, sy0) * fx * (1.0 - fy) +
                    safeA(sx0, sy1) * (1.0 - fx) * fy +
                    safeA(sx1, sy1) * fx * fy;
            }

            // Alpha matte: fill hanya kelihatan di dalam alpha layer asli
            // mattedFill = min(shiftedAlpha, origAlpha)
            // Invert shiftedAlpha: fill kuat di tepi (shiftedAlpha kecil = jauh dari isi layer)
            // lalu clamp ke origAlpha supaya fill tidak keluar dari layer asli
            double invertedFill = 1.0 - shiftedAlpha;
            double mattedFill = invertedFill < origAlpha ? invertedFill : origAlpha;
            double rimAlpha = mattedFill * opacity;

            // Composite rimColor di depan layer asli
            const double invRim = 1.0 - rimAlpha;
            double outR = sp.red * invRim + rimR_n * 255.0 * rimAlpha;
            double outG = sp.green * invRim + rimG_n * 255.0 * rimAlpha;
            double outB = sp.blue * invRim + rimB_n * 255.0 * rimAlpha;

            dp.red = clamp255((int)outR);
            dp.green = clamp255((int)outG);
            dp.blue = clamp255((int)outB);
            dp.alpha = sp.alpha;
        }
    }

    return PF_Err_NONE;
}

// ─────────────────────────────────────────────────────────────────────────────
// Rim Light Render — 16-bit
// ─────────────────────────────────────────────────────────────────────────────

static PF_Err RimRender16(
    PF_InData* in_data,
    PF_LayerDef* src,
    PF_LayerDef* dst,
    const RimLightInfo& info)
{
    const A_long width = dst->width;
    const A_long height = dst->height;
    const A_long src_stride = src->rowbytes / sizeof(PF_Pixel16);
    const A_long dst_stride = dst->rowbytes / sizeof(PF_Pixel16);

    const PF_Pixel16* src_base = reinterpret_cast<const PF_Pixel16*>(src->data);
    PF_Pixel16* dst_base = reinterpret_cast<PF_Pixel16*>(dst->data);

    const double angle_rad = info.rim_angle * 3.14159265358979323846 / 180.0;
    const double dist = info.rim_size;
    const double opacity = info.rim_opacity / 100.0;

    const double dx = cos(angle_rad) * dist;
    const double dy = -sin(angle_rad) * dist;

    const double rimR_n = info.rim_color.red / 255.0;
    const double rimG_n = info.rim_color.green / 255.0;
    const double rimB_n = info.rim_color.blue / 255.0;

    for (A_long y = 0; y < height; ++y) {
        for (A_long x = 0; x < width; ++x) {
            const PF_Pixel16& sp = src_base[y * src_stride + x];
            PF_Pixel16& dp = dst_base[y * dst_stride + x];

            const double origAlpha = sp.alpha / 32768.0;

            // Sample ke arah BERLAWANAN cahaya (negasi dx/dy) — sama dengan RimRender8
            const double sx_f = (double)x - dx;
            const double sy_f = (double)y - dy;

            double shiftedAlpha = 0.0;
            {
                const int sx0 = (int)floor(sx_f);
                const int sy0 = (int)floor(sy_f);
                const int sx1 = sx0 + 1;
                const int sy1 = sy0 + 1;
                const double fx = sx_f - (double)sx0;
                const double fy = sy_f - (double)sy0;

                auto safeA = [&](int px, int py) -> double {
                    // Return 0.0 jika out-of-bounds: piksel di luar canvas tidak ada.
                    if (px < 0 || px >= width || py < 0 || py >= height) return 0.0;
                    return src_base[py * src_stride + px].alpha / 32768.0;
                    };

                shiftedAlpha =
                    safeA(sx0, sy0) * (1.0 - fx) * (1.0 - fy) +
                    safeA(sx1, sy0) * fx * (1.0 - fy) +
                    safeA(sx0, sy1) * (1.0 - fx) * fy +
                    safeA(sx1, sy1) * fx * fy;
            }

            double invertedFill = 1.0 - shiftedAlpha;
            double mattedFill = invertedFill < origAlpha ? invertedFill : origAlpha;
            double rimAlpha = mattedFill * opacity;

            const double invRim = 1.0 - rimAlpha;
            double outR = sp.red * invRim + rimR_n * 32768.0 * rimAlpha;
            double outG = sp.green * invRim + rimG_n * 32768.0 * rimAlpha;
            double outB = sp.blue * invRim + rimB_n * 32768.0 * rimAlpha;

            dp.red = clamp32768((int)outR);
            dp.green = clamp32768((int)outG);
            dp.blue = clamp32768((int)outB);
            dp.alpha = sp.alpha;
        }
    }

    return PF_Err_NONE;
}

// ─────────────────────────────────────────────────────────────────────────────
// Render dispatcher
// ─────────────────────────────────────────────────────────────────────────────

static PF_Err Render(
    PF_InData* in_data,
    PF_OutData* out_data,
    PF_ParamDef* params[],
    PF_LayerDef* output)
{
    PF_Err       err = PF_Err_NONE;
    PF_LayerDef* input = &params[RIM_INPUT]->u.ld;

    RimLightInfo info;
    AEFX_CLR_STRUCT(info);

    info.rim_color = params[RIM_COLOR]->u.cd.value;
    info.rim_size = params[RIM_SIZE]->u.fs_d.value;
    info.rim_opacity = params[RIM_OPACITY]->u.fs_d.value;
    info.rim_angle = params[RIM_ANGLE]->u.ad.value / 65536.0;

    if (PF_WORLD_IS_DEEP(output)) {
        err = RimRender16(in_data, input, output, info);
    }
    else {
        err = RimRender8(in_data, input, output, info);
    }

    return err;
}

// ─────────────────────────────────────────────────────────────────────────────
// PreRender
// ─────────────────────────────────────────────────────────────────────────────

static PF_Err PreRender(
    PF_InData* in_data,
    PF_OutData* out_data,
    PF_PreRenderExtra* extra)
{
    extra->output->result_rect = extra->input->output_request.rect;
    extra->output->max_result_rect = extra->input->output_request.rect;
    extra->output->solid = FALSE;
    extra->output->pre_render_data = NULL;
    return PF_Err_NONE;
}

// ─────────────────────────────────────────────────────────────────────────────
// EffectMain
// ─────────────────────────────────────────────────────────────────────────────

extern "C" DllExport PF_Err EffectMain(
    PF_Cmd       cmd,
    PF_InData* in_data,
    PF_OutData* out_data,
    PF_ParamDef* params[],
    PF_LayerDef* output,
    void* extra)
{
    PF_Err err = PF_Err_NONE;
    try {
        switch (cmd) {
        case PF_Cmd_ABOUT:
            err = About(in_data, out_data, params, output);       break;
        case PF_Cmd_GLOBAL_SETUP:
            err = GlobalSetup(in_data, out_data, params, output); break;
        case PF_Cmd_PARAMS_SETUP:
            err = ParamsSetup(in_data, out_data, params, output); break;
        case PF_Cmd_RENDER:
            err = Render(in_data, out_data, params, output);      break;
        case PF_Cmd_SMART_PRE_RENDER:
            err = PreRender(in_data, out_data,
                reinterpret_cast<PF_PreRenderExtra*>(extra));     break;
        default: break;
        }
    }
    catch (PF_Err& thrown) { err = thrown; }
    return err;
}