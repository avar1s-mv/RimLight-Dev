#pragma once

#ifndef RIMLIGHT_STRINGS_H
#define RIMLIGHT_STRINGS_H

typedef enum {
    StrID_NONE,
    StrID_Name,
    StrID_Description,

    StrID_RimColor_Param_Name,
    StrID_RimSize_Param_Name,
    StrID_RimOpacity_Param_Name,
    StrID_RimAngle_Param_Name,

    StrID_NUMTYPES
} StrIDType;

#endif // RIMLIGHT_STRINGS_H