﻿#include "RimLight.h"
#include <new>

static inline A_u_char clamp255(int v)
{
    if (v < 0)   return 0;
    if (v > 255) return 255;
    return static_cast<A_u_char>(v);
}

static inline A_u_short clamp32768(int v)
{
    if (v < 0)     return 0;
    if (v > 32768) return 32768;
    return static_cast<A_u_short>(v);
}

// ─────────────────────────────────────────────────────────────────────────────
// Softness: separable box-blur pada rim-mask (float buffer).
// Dijalankan 3x pass (approx. Gaussian) untuk hasil yang halus.
// radius dalam pixel (bisa fractional — di-round ke integer passes).
// ─────────────────────────────────────────────────────────────────────────────

static void BoxBlurH(double* buf, double* tmp, A_long w, A_long h, int r)
{
    if (r <= 0) return;
    const double inv = 1.0 / (2 * r + 1);
    for (A_long y = 0; y < h; ++y) {
        double* row = buf + y * w;
        double* trow = tmp + y * w;
        // build running sum for first window
        double sum = 0.0;
        for (int i = -r; i <= r; ++i) {
            int xi = i < 0 ? 0 : (i >= w ? w - 1 : i);
            sum += row[xi];
        }
        for (A_long x = 0; x < w; ++x) {
            trow[x] = sum * inv;
            int xl = x - r;     xl = xl < 0 ? 0 : xl;
            int xr = x + r + 1; xr = xr >= w ? w - 1 : xr;
            sum += row[xr] - row[xl];
        }
        for (A_long x = 0; x < w; ++x) row[x] = trow[x];
    }
}

static void BoxBlurV(double* buf, double* tmp, A_long w, A_long h, int r)
{
    if (r <= 0) return;
    const double inv = 1.0 / (2 * r + 1);
    for (A_long x = 0; x < w; ++x) {
        double sum = 0.0;
        for (int i = -r; i <= r; ++i) {
            int yi = i < 0 ? 0 : (i >= h ? h - 1 : i);
            sum += buf[yi * w + x];
        }
        for (A_long y = 0; y < h; ++y) {
            tmp[y * w + x] = sum * inv;
            int yt = y - r;     yt = yt < 0 ? 0 : yt;
            int yb = y + r + 1; yb = yb >= h ? h - 1 : yb;
            sum += buf[yb * w + x] - buf[yt * w + x];
        }
        for (A_long y = 0; y < h; ++y) buf[y * w + x] = tmp[y * w + x];
    }
}

// 3-pass box blur ≈ Gaussian. radius = 0 → skip.
static void ApplySoftness(double* mask, A_long w, A_long h, double softness)
{
    if (softness <= 0.0 || w <= 0 || h <= 0) return;
    // Convert softness (sigma-like) to box radius: r ≈ sigma * sqrt(3)
    // We pick r = round(softness * 0.85) so slider 0–100 maps nicely 0–85px.
    const int r = static_cast<int>(softness * 0.85 + 0.5);
    if (r <= 0) return;

    double* tmp = new (std::nothrow) double[static_cast<size_t>(w) * h];
    if (!tmp) return;

    for (int pass = 0; pass < 3; ++pass) {
        BoxBlurH(mask, tmp, w, h, r);
        BoxBlurV(mask, tmp, w, h, r);
    }
    delete[] tmp;
}

// ─────────────────────────────────────────────────────────────────────────────
// Blend composite: returns blended channel value (normalised 0–1)
//   mode 0 = Normal, 1 = Add, 2 = Screen
// src_n  = source channel normalised
// rim_n  = rim color channel normalised
// alpha  = rim alpha (already opacity-weighted)
// ─────────────────────────────────────────────────────────────────────────────

static inline double BlendChannel(double src_n, double rim_n, double alpha, A_long mode)
{
    switch (mode) {
    case RIM_BLEND_ADD:
        // Add: clamp(src + rim*alpha)
        return src_n + rim_n * alpha;

    case RIM_BLEND_SCREEN:
        // Screen: 1 - (1-src)*(1-rim*alpha)
        return 1.0 - (1.0 - src_n) * (1.0 - rim_n * alpha);

    case RIM_BLEND_NORMAL:
    default:
        // Normal over: src*(1-alpha) + rim*alpha
        return src_n * (1.0 - alpha) + rim_n * alpha;
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// About
// ─────────────────────────────────────────────────────────────────────────────

static PF_Err About(
    PF_InData* in_data,
    PF_OutData* out_data,
    PF_ParamDef* params[],
    PF_LayerDef* output)
{
    AEGP_SuiteHandler suites(in_data->pica_basicP);
    suites.ANSICallbacksSuite1()->sprintf(
        out_data->return_msg,
        "%s v%d.%d\r%s",
        STR(StrID_Name),
        MAJOR_VERSION,
        MINOR_VERSION,
        STR(StrID_Description));
    return PF_Err_NONE;
}

// ─────────────────────────────────────────────────────────────────────────────
// GlobalSetup
// ─────────────────────────────────────────────────────────────────────────────

static PF_Err GlobalSetup(
    PF_InData* in_data,
    PF_OutData* out_data,
    PF_ParamDef* params[],
    PF_LayerDef* output)
{
    out_data->my_version = 524289;

    out_data->out_flags =
        PF_OutFlag_DEEP_COLOR_AWARE |
        PF_OutFlag_SEND_UPDATE_PARAMS_UI;

    out_data->out_flags2 =0;

    return PF_Err_NONE;
}

// ─────────────────────────────────────────────────────────────────────────────
// ParamsSetup
// ─────────────────────────────────────────────────────────────────────────────

static PF_Err ParamsSetup(
    PF_InData* in_data,
    PF_OutData* out_data,
    PF_ParamDef* params[],
    PF_LayerDef* output)
{
    PF_Err      err = PF_Err_NONE;
    PF_ParamDef def;

    AEFX_CLR_STRUCT(def);
    PF_ADD_COLOR(STR(StrID_RimColor_Param_Name), PF_MAX_CHAN8, PF_MAX_CHAN8, PF_MAX_CHAN8, RIM_COLOR);

    AEFX_CLR_STRUCT(def);
    PF_ADD_FLOAT_SLIDERX(STR(StrID_RimSize_Param_Name),
        RIM_SIZE_MIN, RIM_SIZE_MAX, RIM_SIZE_MIN, RIM_SIZE_MAX, RIM_SIZE_DFLT,
        PF_Precision_HUNDREDTHS, 0, 0, RIM_SIZE);

    AEFX_CLR_STRUCT(def);
    PF_ADD_FLOAT_SLIDERX(STR(StrID_RimOpacity_Param_Name),
        RIM_OPACITY_MIN, RIM_OPACITY_MAX, RIM_OPACITY_MIN, RIM_OPACITY_MAX, RIM_OPACITY_DFLT,
        PF_Precision_HUNDREDTHS, 0, 0, RIM_OPACITY);

    AEFX_CLR_STRUCT(def);
    PF_ADD_ANGLE(STR(StrID_RimAngle_Param_Name), RIM_ANGLE_DFLT, RIM_ANGLE);

    AEFX_CLR_STRUCT(def);
    PF_ADD_FLOAT_SLIDERX(STR(StrID_RimSoftness_Param_Name),
        RIM_SOFTNESS_MIN, RIM_SOFTNESS_MAX, RIM_SOFTNESS_MIN, RIM_SOFTNESS_MAX, RIM_SOFTNESS_DFLT,
        PF_Precision_HUNDREDTHS, 0, 0, RIM_SOFTNESS);

    AEFX_CLR_STRUCT(def);
    PF_ADD_POPUP(STR(StrID_RimBlendMode_Param_Name),
        3,                       // num choices
        RIM_BLEND_DFLT + 1,      // 1-based default (AE popup is 1-based)
        "Normal|Add|Screen",     // pipe-delimited choices
        RIM_BLEND_MODE);

    out_data->num_params = RIM_NUM_PARAMS;
    return err;
}

// ─────────────────────────────────────────────────────────────────────────────
// Rim Light Render — 8-bit
//
// Konsep: fill putih digeser ke arah cahaya, lalu di-alpha matte ke layer asli.
//
//   Angle = arah datangnya cahaya (default 180 = dari kiri).
//   Fill solid digeser sejauh Size pixel ke arah BERLAWANAN angle (menjauhi cahaya).
//   Fill di-clamp oleh alpha layer asli (hanya kelihatan di dalam alpha layer).
//   Hasilnya di-composite di DEPAN layer asli.
//
//   Per pixel (x, y):
//     1. origAlpha    = alpha layer asli di (x, y)
//     2. shiftedAlpha = alpha layer asli di (x - dx, y - dy)  ← geser menjauhi cahaya
//     3. invertedFill = 1 - shiftedAlpha                      ← rim kuat di tepi menghadap cahaya
//     4. mattedFill   = min(invertedFill, origAlpha)           ← fill di-clamp alpha asli
//     5. rimAlpha     = mattedFill * opacity
//     6. Composite: rimColor over layer asli, dengan rimAlpha
//     7. outAlpha     = origAlpha  (alpha tidak berubah, rim hanya di dalam layer)
// ─────────────────────────────────────────────────────────────────────────────

static PF_Err RimRender8(
    PF_InData* in_data,
    PF_LayerDef* src,
    PF_LayerDef* dst,
    const RimLightInfo& info)
{
    const A_long width = dst->width;
    const A_long height = dst->height;
    const A_long src_stride = src->rowbytes / sizeof(PF_Pixel8);
    const A_long dst_stride = dst->rowbytes / sizeof(PF_Pixel8);

    const PF_Pixel8* src_base = reinterpret_cast<const PF_Pixel8*>(src->data);
    PF_Pixel8* dst_base = reinterpret_cast<PF_Pixel8*>(dst->data);

    const double angle_rad = info.rim_angle * 3.14159265358979323846 / 360.0;
    const double dist = info.rim_size;
    const double opacity = info.rim_opacity / 100.0;

    // Downsample fix: scale offset by downsample factor so rim size
    // is consistent across preview resolutions.
    const double ds_x = (double)in_data->downsample_x.num / (double)in_data->downsample_x.den;
    const double ds_y = (double)in_data->downsample_y.num / (double)in_data->downsample_y.den;

    // Arah geser fill: KE ARAH BERLAWANAN cahaya
    const double dx = cos(angle_rad) * dist * ds_x;
    const double dy = -sin(angle_rad) * dist * ds_y;

    const double rimR_n = info.rim_color.red / 255.0;
    const double rimG_n = info.rim_color.green / 255.0;
    const double rimB_n = info.rim_color.blue / 255.0;

    // ── Pass 1: build rim mask (mattedFill) into a float buffer ──────────────
    const size_t nPix = static_cast<size_t>(width) * height;
    double* mask = new (std::nothrow) double[nPix];
    if (!mask) return PF_Err_OUT_OF_MEMORY;

    for (A_long y = 0; y < height; ++y) {
        for (A_long x = 0; x < width; ++x) {
            const PF_Pixel8& sp = src_base[y * src_stride + x];
            const double origAlpha = sp.alpha / 255.0;

            const double sx_f = (double)x - dx;
            const double sy_f = (double)y - dy;
            const int sx0 = (int)floor(sx_f);
            const int sy0 = (int)floor(sy_f);
            const double fx = sx_f - (double)sx0;
            const double fy = sy_f - (double)sy0;

            auto safeA = [&](int px, int py) -> double {
                if (px < 0 || px >= width || py < 0 || py >= height) return 0.0;
                return src_base[py * src_stride + px].alpha / 255.0;
            };

            const double shiftedAlpha =
                safeA(sx0,     sy0)     * (1.0 - fx) * (1.0 - fy) +
                safeA(sx0 + 1, sy0)     * fx          * (1.0 - fy) +
                safeA(sx0,     sy0 + 1) * (1.0 - fx) * fy          +
                safeA(sx0 + 1, sy0 + 1) * fx          * fy;

            const double invertedFill = 1.0 - shiftedAlpha;
            const double mattedFill = invertedFill < origAlpha ? invertedFill : origAlpha;
            mask[y * width + x] = mattedFill;
        }
    }

    // ── Pass 2: apply softness blur on mask ───────────────────────────────────
    ApplySoftness(mask, width, height, info.rim_softness * ds_x);

    // ── Pass 3: composite ─────────────────────────────────────────────────────
    for (A_long y = 0; y < height; ++y) {
        for (A_long x = 0; x < width; ++x) {
            const PF_Pixel8& sp = src_base[y * src_stride + x];
            PF_Pixel8& dp = dst_base[y * dst_stride + x];

            const double rimAlpha = mask[y * width + x] * opacity;

            dp.red   = clamp255((int)(BlendChannel(sp.red   / 255.0, rimR_n, rimAlpha, info.rim_blend_mode) * 255.0));
            dp.green = clamp255((int)(BlendChannel(sp.green / 255.0, rimG_n, rimAlpha, info.rim_blend_mode) * 255.0));
            dp.blue  = clamp255((int)(BlendChannel(sp.blue  / 255.0, rimB_n, rimAlpha, info.rim_blend_mode) * 255.0));
            dp.alpha = sp.alpha;
        }
    }

    delete[] mask;
    return PF_Err_NONE;
}

// ─────────────────────────────────────────────────────────────────────────────
// Rim Light Render — 16-bit
// ─────────────────────────────────────────────────────────────────────────────

static PF_Err RimRender16(
    PF_InData* in_data,
    PF_LayerDef* src,
    PF_LayerDef* dst,
    const RimLightInfo& info)
{
    const A_long width = dst->width;
    const A_long height = dst->height;
    const A_long src_stride = src->rowbytes / sizeof(PF_Pixel16);
    const A_long dst_stride = dst->rowbytes / sizeof(PF_Pixel16);

    const PF_Pixel16* src_base = reinterpret_cast<const PF_Pixel16*>(src->data);
    PF_Pixel16* dst_base = reinterpret_cast<PF_Pixel16*>(dst->data);

    const double angle_rad = info.rim_angle * 3.14159265358979323846 / 360.0;
    const double dist = info.rim_size;
    const double opacity = info.rim_opacity / 100.0;

    // Downsample fix: scale offset by downsample factor so rim size
    // is consistent across preview resolutions.
    const double ds_x = (double)in_data->downsample_x.num / (double)in_data->downsample_x.den;
    const double ds_y = (double)in_data->downsample_y.num / (double)in_data->downsample_y.den;

    const double dx = cos(angle_rad) * dist * ds_x;
    const double dy = -sin(angle_rad) * dist * ds_y;

    const double rimR_n = info.rim_color.red / 255.0;
    const double rimG_n = info.rim_color.green / 255.0;
    const double rimB_n = info.rim_color.blue / 255.0;

    // ── Pass 1: build rim mask ────────────────────────────────────────────────
    const size_t nPix = static_cast<size_t>(width) * height;
    double* mask = new (std::nothrow) double[nPix];
    if (!mask) return PF_Err_OUT_OF_MEMORY;

    for (A_long y = 0; y < height; ++y) {
        for (A_long x = 0; x < width; ++x) {
            const PF_Pixel16& sp = src_base[y * src_stride + x];
            const double origAlpha = sp.alpha / 32768.0;

            const double sx_f = (double)x - dx;
            const double sy_f = (double)y - dy;
            const int sx0 = (int)floor(sx_f);
            const int sy0 = (int)floor(sy_f);
            const double fx = sx_f - (double)sx0;
            const double fy = sy_f - (double)sy0;

            auto safeA = [&](int px, int py) -> double {
                if (px < 0 || px >= width || py < 0 || py >= height) return 0.0;
                return src_base[py * src_stride + px].alpha / 32768.0;
            };

            const double shiftedAlpha =
                safeA(sx0,     sy0)     * (1.0 - fx) * (1.0 - fy) +
                safeA(sx0 + 1, sy0)     * fx          * (1.0 - fy) +
                safeA(sx0,     sy0 + 1) * (1.0 - fx) * fy          +
                safeA(sx0 + 1, sy0 + 1) * fx          * fy;

            const double invertedFill = 1.0 - shiftedAlpha;
            const double mattedFill = invertedFill < origAlpha ? invertedFill : origAlpha;
            mask[y * width + x] = mattedFill;
        }
    }

    // ── Pass 2: softness blur ─────────────────────────────────────────────────
    ApplySoftness(mask, width, height, info.rim_softness * ds_x);

    // ── Pass 3: composite ─────────────────────────────────────────────────────
    for (A_long y = 0; y < height; ++y) {
        for (A_long x = 0; x < width; ++x) {
            const PF_Pixel16& sp = src_base[y * src_stride + x];
            PF_Pixel16& dp = dst_base[y * dst_stride + x];

            const double rimAlpha = mask[y * width + x] * opacity;

            dp.red   = clamp32768((int)(BlendChannel(sp.red   / 32768.0, rimR_n, rimAlpha, info.rim_blend_mode) * 32768.0));
            dp.green = clamp32768((int)(BlendChannel(sp.green / 32768.0, rimG_n, rimAlpha, info.rim_blend_mode) * 32768.0));
            dp.blue  = clamp32768((int)(BlendChannel(sp.blue  / 32768.0, rimB_n, rimAlpha, info.rim_blend_mode) * 32768.0));
            dp.alpha = sp.alpha;
        }
    }

    delete[] mask;
    return PF_Err_NONE;
}

// ─────────────────────────────────────────────────────────────────────────────
// Render dispatcher
// ─────────────────────────────────────────────────────────────────────────────

static PF_Err Render(
    PF_InData* in_data,
    PF_OutData* out_data,
    PF_ParamDef* params[],
    PF_LayerDef* output)
{
    PF_Err       err = PF_Err_NONE;
    PF_LayerDef* input = &params[RIM_INPUT]->u.ld;

    RimLightInfo info;
    AEFX_CLR_STRUCT(info);

    info.rim_color = params[RIM_COLOR]->u.cd.value;
    info.rim_size = params[RIM_SIZE]->u.fs_d.value;
    info.rim_opacity = params[RIM_OPACITY]->u.fs_d.value;
    info.rim_angle = params[RIM_ANGLE]->u.ad.value / 65536.0;
    info.rim_softness = params[RIM_SOFTNESS]->u.fs_d.value;
    info.rim_blend_mode = params[RIM_BLEND_MODE]->u.pd.value - 1; // AE popup is 1-based

    if (PF_WORLD_IS_DEEP(output)) {
        err = RimRender16(in_data, input, output, info);
    }
    else {
        err = RimRender8(in_data, input, output, info);
    }

    return err;
}

// ─────────────────────────────────────────────────────────────────────────────
// PreRender
//
// Kita perlu sample alpha di (x - dx, y - dy) — bisa jatuh di luar tile.
// Solusi: minta AE suplai input yang lebih besar dari output tile sebesar
// ceil(rim_size) ke semua sisi (checkout_rect di-expand), sehingga
// safeA tidak pernah keluar dari data yang disediakan AE.
// ─────────────────────────────────────────────────────────────────────────────

static PF_Err PreRender(
    PF_InData* in_data,
    PF_OutData* out_data,
    PF_PreRenderExtra* extra)
{
    PF_Err err = PF_Err_NONE;

    // Baca rim_size dan rim_softness dari parameter
    PF_ParamDef rimSizeParam, rimSoftnessParam;
    AEFX_CLR_STRUCT(rimSizeParam);
    AEFX_CLR_STRUCT(rimSoftnessParam);
    ERR(PF_CHECKOUT_PARAM(in_data, RIM_SIZE, in_data->current_time,
        in_data->time_step, in_data->time_scale, &rimSizeParam));
    ERR(PF_CHECKOUT_PARAM(in_data, RIM_SOFTNESS, in_data->current_time,
        in_data->time_step, in_data->time_scale, &rimSoftnessParam));

    const double softRadius = err ? 0.0 : rimSoftnessParam.u.fs_d.value * 0.85 * 3.0; // 3 passes
    const A_long pad = err ? 64 :
        static_cast<A_long>(ceil(rimSizeParam.u.fs_d.value + softRadius)) + 4;

    PF_CHECKIN_PARAM(in_data, &rimSizeParam);
    PF_CHECKIN_PARAM(in_data, &rimSoftnessParam);

    // Output rect: sama dengan yang diminta AE (tile ini)
    extra->output->result_rect = extra->input->output_request.rect;
    extra->output->max_result_rect = extra->input->output_request.rect;
    extra->output->solid = FALSE;
    extra->output->pre_render_data = NULL;

    // Checkout input yang lebih besar: expand ke semua sisi sebesar pad
    PF_RenderRequest req = extra->input->output_request;
    req.rect.left -= pad;
    req.rect.top -= pad;
    req.rect.right += pad;
    req.rect.bottom += pad;
    req.preserve_rgb_of_zero_alpha = FALSE;

    // checkout_layer argumen ke-8 adalah PF_CheckoutResult*, bukan PF_LRect*
    PF_CheckoutResult checkout_result;
    AEFX_CLR_STRUCT(checkout_result);

    ERR(extra->cb->checkout_layer(in_data->effect_ref,
        RIM_INPUT,
        RIM_INPUT,
        &req,
        in_data->current_time,
        in_data->time_step,
        in_data->time_scale,
        &checkout_result));
    // result_rect dan max_result_rect sudah di-set ke tile output di atas.

    return err;
}

// ─────────────────────────────────────────────────────────────────────────────
// SmartRender — dipanggil saat full render (SUPPORTS_SMART_RENDER aktif)
// Input layer sudah di-checkout oleh PreRender dengan rect yang di-expand.
// ─────────────────────────────────────────────────────────────────────────────

static PF_Err SmartRender(
    PF_InData* in_data,
    PF_OutData* out_data,
    PF_SmartRenderExtra* extra)
{
    PF_Err err = PF_Err_NONE;

    PF_EffectWorld* input_world = NULL;
    PF_EffectWorld* output_world = NULL;

    ERR(extra->cb->checkout_layer_pixels(in_data->effect_ref, RIM_INPUT, &input_world));
    ERR(extra->cb->checkout_output(in_data->effect_ref, &output_world));

    if (!err && input_world && output_world) {
        RimLightInfo info;
        AEFX_CLR_STRUCT(info);

        PF_ParamDef colorParam, sizeParam, opacityParam, angleParam, softnessParam, blendParam;
        AEFX_CLR_STRUCT(colorParam);
        AEFX_CLR_STRUCT(sizeParam);
        AEFX_CLR_STRUCT(opacityParam);
        AEFX_CLR_STRUCT(angleParam);
        AEFX_CLR_STRUCT(softnessParam);
        AEFX_CLR_STRUCT(blendParam);

        ERR(PF_CHECKOUT_PARAM(in_data, RIM_COLOR,      in_data->current_time, in_data->time_step, in_data->time_scale, &colorParam));
        ERR(PF_CHECKOUT_PARAM(in_data, RIM_SIZE,       in_data->current_time, in_data->time_step, in_data->time_scale, &sizeParam));
        ERR(PF_CHECKOUT_PARAM(in_data, RIM_OPACITY,    in_data->current_time, in_data->time_step, in_data->time_scale, &opacityParam));
        ERR(PF_CHECKOUT_PARAM(in_data, RIM_ANGLE,      in_data->current_time, in_data->time_step, in_data->time_scale, &angleParam));
        ERR(PF_CHECKOUT_PARAM(in_data, RIM_SOFTNESS,   in_data->current_time, in_data->time_step, in_data->time_scale, &softnessParam));
        ERR(PF_CHECKOUT_PARAM(in_data, RIM_BLEND_MODE, in_data->current_time, in_data->time_step, in_data->time_scale, &blendParam));

        if (!err) {
            info.rim_color      = colorParam.u.cd.value;
            info.rim_size       = sizeParam.u.fs_d.value;
            info.rim_opacity    = opacityParam.u.fs_d.value;
            info.rim_angle      = angleParam.u.ad.value / 65536.0;
            info.rim_softness   = softnessParam.u.fs_d.value;
            info.rim_blend_mode = blendParam.u.pd.value - 1; // AE popup is 1-based

            // ----------------------------------------------------------------
            // Coordinate mapping: output pixel (x,y) -> input buffer (ix,iy)
            //
            // origin_x/y in AE SmartRender = comp-space coordinates (top-left
            // of each buffer in composition space). The difference gives how
            // many pixels output (0,0) is offset inside the input buffer.
            //
            //   ix = x + (output->origin_x - input->origin_x)
            //   iy = y + (output->origin_y - input->origin_y)
            //
            // This is stable even when layer size != comp size because both
            // origins are in the same comp-space coordinate system.
            //
            // Downsample fix: rim_size is in full-resolution pixels.
            // At lower quality, AE scales all world coordinates, so dx/dy
            // must also be scaled to match the buffer resolution.
            // ----------------------------------------------------------------
            const double ds_x = (double)in_data->downsample_x.num / (double)in_data->downsample_x.den;
            const double ds_y = (double)in_data->downsample_y.num / (double)in_data->downsample_y.den;

            const A_long off_x = output_world->origin_x - input_world->origin_x;
            const A_long off_y = output_world->origin_y - input_world->origin_y;

            const double angle_rad = info.rim_angle * 3.14159265358979323846 / 360.0;
            const double dx = cos(angle_rad) * info.rim_size * ds_x;
            const double dy = -sin(angle_rad) * info.rim_size * ds_y;
            const double opacity = info.rim_opacity / 100.0;

            if (PF_WORLD_IS_DEEP(output_world)) {
                const A_long out_w = output_world->width;
                const A_long out_h = output_world->height;
                const A_long in_w = input_world->width;
                const A_long in_h = input_world->height;
                const A_long src_stride = input_world->rowbytes / sizeof(PF_Pixel16);
                const A_long dst_stride = output_world->rowbytes / sizeof(PF_Pixel16);
                const PF_Pixel16* src_base = reinterpret_cast<const PF_Pixel16*>(input_world->data);
                PF_Pixel16* dst_base = reinterpret_cast<PF_Pixel16*>(output_world->data);

                const double rimR_n = info.rim_color.red / 255.0;
                const double rimG_n = info.rim_color.green / 255.0;
                const double rimB_n = info.rim_color.blue / 255.0;

                // ── Pass 1: rim mask ──────────────────────────────────────────
                const size_t nPix = static_cast<size_t>(out_w) * out_h;
                double* mask = new (std::nothrow) double[nPix];
                if (!mask) { err = PF_Err_OUT_OF_MEMORY; goto checkin_params; }

                for (A_long y = 0; y < out_h; ++y) {
                    for (A_long x = 0; x < out_w; ++x) {
                        const A_long ix = x + off_x;
                        const A_long iy = y + off_y;

                        if (ix < 0 || ix >= in_w || iy < 0 || iy >= in_h) {
                            mask[y * out_w + x] = 0.0;
                            dst_base[y * dst_stride + x] = {};
                            continue;
                        }

                        const PF_Pixel16& sp = src_base[iy * src_stride + ix];
                        const double origAlpha = sp.alpha / 32768.0;

                        const double sx_f = (double)ix - dx;
                        const double sy_f = (double)iy - dy;
                        const int sx0 = (int)floor(sx_f);
                        const int sy0 = (int)floor(sy_f);
                        const double fx = sx_f - sx0;
                        const double fy = sy_f - sy0;

                        auto safeA = [&](int px, int py) -> double {
                            if (px < 0 || px >= in_w || py < 0 || py >= in_h) return 0.0;
                            return src_base[py * src_stride + px].alpha / 32768.0;
                        };

                        const double shiftedAlpha =
                            safeA(sx0,     sy0)     * (1.0 - fx) * (1.0 - fy) +
                            safeA(sx0 + 1, sy0)     * fx          * (1.0 - fy) +
                            safeA(sx0,     sy0 + 1) * (1.0 - fx) * fy          +
                            safeA(sx0 + 1, sy0 + 1) * fx          * fy;

                        const double invertedFill = 1.0 - shiftedAlpha;
                        const double mattedFill = invertedFill < origAlpha ? invertedFill : origAlpha;
                        mask[y * out_w + x] = mattedFill;
                    }
                }

                // ── Pass 2: softness blur ─────────────────────────────────────
                ApplySoftness(mask, out_w, out_h, info.rim_softness * ds_x);

                // ── Pass 3: composite ─────────────────────────────────────────
                for (A_long y = 0; y < out_h; ++y) {
                    for (A_long x = 0; x < out_w; ++x) {
                        const A_long ix = x + off_x;
                        const A_long iy = y + off_y;
                        if (ix < 0 || ix >= in_w || iy < 0 || iy >= in_h) continue;

                        const PF_Pixel16& sp = src_base[iy * src_stride + ix];
                        PF_Pixel16& dp = dst_base[y * dst_stride + x];
                        const double rimAlpha = mask[y * out_w + x] * opacity;

                        dp.red   = clamp32768((int)(BlendChannel(sp.red   / 32768.0, rimR_n, rimAlpha, info.rim_blend_mode) * 32768.0));
                        dp.green = clamp32768((int)(BlendChannel(sp.green / 32768.0, rimG_n, rimAlpha, info.rim_blend_mode) * 32768.0));
                        dp.blue  = clamp32768((int)(BlendChannel(sp.blue  / 32768.0, rimB_n, rimAlpha, info.rim_blend_mode) * 32768.0));
                        dp.alpha = sp.alpha;
                    }
                }
                delete[] mask;
            }
            else {
                const A_long out_w = output_world->width;
                const A_long out_h = output_world->height;
                const A_long in_w = input_world->width;
                const A_long in_h = input_world->height;
                const A_long src_stride = input_world->rowbytes / sizeof(PF_Pixel8);
                const A_long dst_stride = output_world->rowbytes / sizeof(PF_Pixel8);
                const PF_Pixel8* src_base = reinterpret_cast<const PF_Pixel8*>(input_world->data);
                PF_Pixel8* dst_base = reinterpret_cast<PF_Pixel8*>(output_world->data);

                const double rimR_n = info.rim_color.red / 255.0;
                const double rimG_n = info.rim_color.green / 255.0;
                const double rimB_n = info.rim_color.blue / 255.0;

                // ── Pass 1: rim mask ──────────────────────────────────────────
                const size_t nPix = static_cast<size_t>(out_w) * out_h;
                double* mask = new (std::nothrow) double[nPix];
                if (!mask) { err = PF_Err_OUT_OF_MEMORY; goto checkin_params; }

                for (A_long y = 0; y < out_h; ++y) {
                    for (A_long x = 0; x < out_w; ++x) {
                        const A_long ix = x + off_x;
                        const A_long iy = y + off_y;

                        if (ix < 0 || ix >= in_w || iy < 0 || iy >= in_h) {
                            mask[y * out_w + x] = 0.0;
                            dst_base[y * dst_stride + x] = {};
                            continue;
                        }

                        const PF_Pixel8& sp = src_base[iy * src_stride + ix];
                        const double origAlpha = sp.alpha / 255.0;

                        const double sx_f = (double)ix - dx;
                        const double sy_f = (double)iy - dy;
                        const int sx0 = (int)floor(sx_f);
                        const int sy0 = (int)floor(sy_f);
                        const double fx = sx_f - sx0;
                        const double fy = sy_f - sy0;

                        auto safeA = [&](int px, int py) -> double {
                            if (px < 0 || px >= in_w || py < 0 || py >= in_h) return 0.0;
                            return src_base[py * src_stride + px].alpha / 255.0;
                        };

                        const double shiftedAlpha =
                            safeA(sx0,     sy0)     * (1.0 - fx) * (1.0 - fy) +
                            safeA(sx0 + 1, sy0)     * fx          * (1.0 - fy) +
                            safeA(sx0,     sy0 + 1) * (1.0 - fx) * fy          +
                            safeA(sx0 + 1, sy0 + 1) * fx          * fy;

                        const double invertedFill = 1.0 - shiftedAlpha;
                        const double mattedFill = invertedFill < origAlpha ? invertedFill : origAlpha;
                        mask[y * out_w + x] = mattedFill;
                    }
                }

                // ── Pass 2: softness blur ─────────────────────────────────────
                ApplySoftness(mask, out_w, out_h, info.rim_softness * ds_x);

                // ── Pass 3: composite ─────────────────────────────────────────
                for (A_long y = 0; y < out_h; ++y) {
                    for (A_long x = 0; x < out_w; ++x) {
                        const A_long ix = x + off_x;
                        const A_long iy = y + off_y;
                        if (ix < 0 || ix >= in_w || iy < 0 || iy >= in_h) continue;

                        const PF_Pixel8& sp = src_base[iy * src_stride + ix];
                        PF_Pixel8& dp = dst_base[y * dst_stride + x];
                        const double rimAlpha = mask[y * out_w + x] * opacity;

                        dp.red   = clamp255((int)(BlendChannel(sp.red   / 255.0, rimR_n, rimAlpha, info.rim_blend_mode) * 255.0));
                        dp.green = clamp255((int)(BlendChannel(sp.green / 255.0, rimG_n, rimAlpha, info.rim_blend_mode) * 255.0));
                        dp.blue  = clamp255((int)(BlendChannel(sp.blue  / 255.0, rimB_n, rimAlpha, info.rim_blend_mode) * 255.0));
                        dp.alpha = sp.alpha;
                    }
                }
                delete[] mask;
            }
        }

checkin_params:
        PF_CHECKIN_PARAM(in_data, &colorParam);
        PF_CHECKIN_PARAM(in_data, &sizeParam);
        PF_CHECKIN_PARAM(in_data, &opacityParam);
        PF_CHECKIN_PARAM(in_data, &angleParam);
        PF_CHECKIN_PARAM(in_data, &softnessParam);
        PF_CHECKIN_PARAM(in_data, &blendParam);
    }

    if (input_world) extra->cb->checkin_layer_pixels(in_data->effect_ref, RIM_INPUT);
    // output world tidak perlu di-checkin

    return err;
}

// -----------------------------------------------------------------------------

extern "C" DllExport PF_Err EffectMain(
    PF_Cmd       cmd,
    PF_InData* in_data,
    PF_OutData* out_data,
    PF_ParamDef* params[],
    PF_LayerDef* output,
    void* extra)
{
    PF_Err err = PF_Err_NONE;
    try {
        switch (cmd) {
        case PF_Cmd_ABOUT:
            err = About(in_data, out_data, params, output);       break;
        case PF_Cmd_GLOBAL_SETUP:
            err = GlobalSetup(in_data, out_data, params, output); break;
        case PF_Cmd_PARAMS_SETUP:
            err = ParamsSetup(in_data, out_data, params, output); break;
        case PF_Cmd_RENDER:
            err = Render(in_data, out_data, params, output);      break;
        case PF_Cmd_SMART_PRE_RENDER:
            err = PreRender(in_data, out_data,
                reinterpret_cast<PF_PreRenderExtra*>(extra));     break;
        case PF_Cmd_SMART_RENDER:
            err = SmartRender(in_data, out_data,
                reinterpret_cast<PF_SmartRenderExtra*>(extra));   break;
        default: break;
        }
    }
    catch (PF_Err& thrown) { err = thrown; }
    return err;
}