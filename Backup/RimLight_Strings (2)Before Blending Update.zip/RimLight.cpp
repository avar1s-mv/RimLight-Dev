﻿#include "RimLight.h"

static inline A_u_char clamp255(int v)
{
    if (v < 0)   return 0;
    if (v > 255) return 255;
    return static_cast<A_u_char>(v);
}

static inline A_u_short clamp32768(int v)
{
    if (v < 0)     return 0;
    if (v > 32768) return 32768;
    return static_cast<A_u_short>(v);
}

// ─────────────────────────────────────────────────────────────────────────────
// About
// ─────────────────────────────────────────────────────────────────────────────

static PF_Err About(
    PF_InData* in_data,
    PF_OutData* out_data,
    PF_ParamDef* params[],
    PF_LayerDef* output)
{
    AEGP_SuiteHandler suites(in_data->pica_basicP);
    suites.ANSICallbacksSuite1()->sprintf(
        out_data->return_msg,
        "%s v%d.%d\r%s",
        STR(StrID_Name),
        MAJOR_VERSION,
        MINOR_VERSION,
        STR(StrID_Description));
    return PF_Err_NONE;
}

// ─────────────────────────────────────────────────────────────────────────────
// GlobalSetup
// ─────────────────────────────────────────────────────────────────────────────

static PF_Err GlobalSetup(
    PF_InData* in_data,
    PF_OutData* out_data,
    PF_ParamDef* params[],
    PF_LayerDef* output)
{
    out_data->my_version = 524289;

    out_data->out_flags =
        PF_OutFlag_DEEP_COLOR_AWARE |
        PF_OutFlag_SEND_UPDATE_PARAMS_UI;

    out_data->out_flags2 =0;

    return PF_Err_NONE;
}

// ─────────────────────────────────────────────────────────────────────────────
// ParamsSetup
// ─────────────────────────────────────────────────────────────────────────────

static PF_Err ParamsSetup(
    PF_InData* in_data,
    PF_OutData* out_data,
    PF_ParamDef* params[],
    PF_LayerDef* output)
{
    PF_Err      err = PF_Err_NONE;
    PF_ParamDef def;

    AEFX_CLR_STRUCT(def);
    PF_ADD_COLOR(STR(StrID_RimColor_Param_Name), PF_MAX_CHAN8, PF_MAX_CHAN8, PF_MAX_CHAN8, RIM_COLOR);

    AEFX_CLR_STRUCT(def);
    PF_ADD_FLOAT_SLIDERX(STR(StrID_RimSize_Param_Name),
        RIM_SIZE_MIN, RIM_SIZE_MAX, RIM_SIZE_MIN, RIM_SIZE_MAX, RIM_SIZE_DFLT,
        PF_Precision_HUNDREDTHS, 0, 0, RIM_SIZE);

    AEFX_CLR_STRUCT(def);
    PF_ADD_FLOAT_SLIDERX(STR(StrID_RimOpacity_Param_Name),
        RIM_OPACITY_MIN, RIM_OPACITY_MAX, RIM_OPACITY_MIN, RIM_OPACITY_MAX, RIM_OPACITY_DFLT,
        PF_Precision_HUNDREDTHS, 0, 0, RIM_OPACITY);

    AEFX_CLR_STRUCT(def);
    PF_ADD_ANGLE(STR(StrID_RimAngle_Param_Name), RIM_ANGLE_DFLT, RIM_ANGLE);

    out_data->num_params = RIM_NUM_PARAMS;
    return err;
}

// ─────────────────────────────────────────────────────────────────────────────
// Rim Light Render — 8-bit
//
// Konsep: fill putih digeser ke arah cahaya, lalu di-alpha matte ke layer asli.
//
//   Angle = arah datangnya cahaya (default 180 = dari kiri).
//   Fill solid digeser sejauh Size pixel ke arah BERLAWANAN angle (menjauhi cahaya).
//   Fill di-clamp oleh alpha layer asli (hanya kelihatan di dalam alpha layer).
//   Hasilnya di-composite di DEPAN layer asli.
//
//   Per pixel (x, y):
//     1. origAlpha    = alpha layer asli di (x, y)
//     2. shiftedAlpha = alpha layer asli di (x - dx, y - dy)  ← geser menjauhi cahaya
//     3. invertedFill = 1 - shiftedAlpha                      ← rim kuat di tepi menghadap cahaya
//     4. mattedFill   = min(invertedFill, origAlpha)           ← fill di-clamp alpha asli
//     5. rimAlpha     = mattedFill * opacity
//     6. Composite: rimColor over layer asli, dengan rimAlpha
//     7. outAlpha     = origAlpha  (alpha tidak berubah, rim hanya di dalam layer)
// ─────────────────────────────────────────────────────────────────────────────

static PF_Err RimRender8(
    PF_InData* in_data,
    PF_LayerDef* src,
    PF_LayerDef* dst,
    const RimLightInfo& info)
{
    const A_long width = dst->width;
    const A_long height = dst->height;
    const A_long src_stride = src->rowbytes / sizeof(PF_Pixel8);
    const A_long dst_stride = dst->rowbytes / sizeof(PF_Pixel8);

    const PF_Pixel8* src_base = reinterpret_cast<const PF_Pixel8*>(src->data);
    PF_Pixel8* dst_base = reinterpret_cast<PF_Pixel8*>(dst->data);

    const double angle_rad = info.rim_angle * 3.14159265358979323846 / 180.0;
    const double dist = info.rim_size;
    const double opacity = info.rim_opacity / 100.0;

    // Arah geser fill: KE ARAH BERLAWANAN cahaya
    // Rim muncul di tepi yang MENGHADAP cahaya.
    // Kita sample alpha di (x - dx, y - dy): arah berlawanan dari sumber cahaya.
    // Jika piksel ada di tepi menghadap cahaya → posisi sample jatuh di luar layer → shiftedAlpha=0
    // → invertedFill=1 → rim penuh. Jika piksel di tengah → shiftedAlpha≈1 → rim=0. ✓
    //
    // AE angle convention: 0°=kanan, CCW positif.
    // Screen Y terbalik → dy negatif = gerak ke atas di buffer.
    const double dx = cos(angle_rad) * dist;
    const double dy = -sin(angle_rad) * dist;

    const double rimR_n = info.rim_color.red / 255.0;
    const double rimG_n = info.rim_color.green / 255.0;
    const double rimB_n = info.rim_color.blue / 255.0;

    for (A_long y = 0; y < height; ++y) {
        for (A_long x = 0; x < width; ++x) {
            const PF_Pixel8& sp = src_base[y * src_stride + x];
            PF_Pixel8& dp = dst_base[y * dst_stride + x];

            const double origAlpha = sp.alpha / 255.0;

            // Sample ke arah BERLAWANAN cahaya (negasi dx/dy)
            const double sx_f = (double)x - dx;
            const double sy_f = (double)y - dy;

            // Bilinear interpolation
            double shiftedAlpha = 0.0;
            {
                const int sx0 = (int)floor(sx_f);
                const int sy0 = (int)floor(sy_f);
                const int sx1 = sx0 + 1;
                const int sy1 = sy0 + 1;
                const double fx = sx_f - (double)sx0;
                const double fy = sy_f - (double)sy0;

                auto safeA = [&](int px, int py) -> double {
                    // Return 0.0 jika out-of-bounds: piksel di luar canvas memang tidak ada.
                    // Clamp ke border justru bikin shiftedAlpha ≠ 0 di tepi canvas → flicker.
                    if (px < 0 || px >= width || py < 0 || py >= height) return 0.0;
                    return src_base[py * src_stride + px].alpha / 255.0;
                    };

                shiftedAlpha =
                    safeA(sx0, sy0) * (1.0 - fx) * (1.0 - fy) +
                    safeA(sx1, sy0) * fx * (1.0 - fy) +
                    safeA(sx0, sy1) * (1.0 - fx) * fy +
                    safeA(sx1, sy1) * fx * fy;
            }

            // Alpha matte: fill hanya kelihatan di dalam alpha layer asli
            // mattedFill = min(shiftedAlpha, origAlpha)
            // Invert shiftedAlpha: fill kuat di tepi (shiftedAlpha kecil = jauh dari isi layer)
            // lalu clamp ke origAlpha supaya fill tidak keluar dari layer asli
            double invertedFill = 1.0 - shiftedAlpha;
            double mattedFill = invertedFill < origAlpha ? invertedFill : origAlpha;
            double rimAlpha = mattedFill * opacity;

            // Composite rimColor di depan layer asli
            const double invRim = 1.0 - rimAlpha;
            double outR = sp.red * invRim + rimR_n * 255.0 * rimAlpha;
            double outG = sp.green * invRim + rimG_n * 255.0 * rimAlpha;
            double outB = sp.blue * invRim + rimB_n * 255.0 * rimAlpha;

            dp.red = clamp255((int)outR);
            dp.green = clamp255((int)outG);
            dp.blue = clamp255((int)outB);
            dp.alpha = sp.alpha;
        }
    }

    return PF_Err_NONE;
}

// ─────────────────────────────────────────────────────────────────────────────
// Rim Light Render — 16-bit
// ─────────────────────────────────────────────────────────────────────────────

static PF_Err RimRender16(
    PF_InData* in_data,
    PF_LayerDef* src,
    PF_LayerDef* dst,
    const RimLightInfo& info)
{
    const A_long width = dst->width;
    const A_long height = dst->height;
    const A_long src_stride = src->rowbytes / sizeof(PF_Pixel16);
    const A_long dst_stride = dst->rowbytes / sizeof(PF_Pixel16);

    const PF_Pixel16* src_base = reinterpret_cast<const PF_Pixel16*>(src->data);
    PF_Pixel16* dst_base = reinterpret_cast<PF_Pixel16*>(dst->data);

    const double angle_rad = info.rim_angle * 3.14159265358979323846 / 180.0;
    const double dist = info.rim_size;
    const double opacity = info.rim_opacity / 100.0;

    const double dx = cos(angle_rad) * dist;
    const double dy = -sin(angle_rad) * dist;

    const double rimR_n = info.rim_color.red / 255.0;
    const double rimG_n = info.rim_color.green / 255.0;
    const double rimB_n = info.rim_color.blue / 255.0;

    for (A_long y = 0; y < height; ++y) {
        for (A_long x = 0; x < width; ++x) {
            const PF_Pixel16& sp = src_base[y * src_stride + x];
            PF_Pixel16& dp = dst_base[y * dst_stride + x];

            const double origAlpha = sp.alpha / 32768.0;

            // Sample ke arah BERLAWANAN cahaya (negasi dx/dy) — sama dengan RimRender8
            const double sx_f = (double)x - dx;
            const double sy_f = (double)y - dy;

            double shiftedAlpha = 0.0;
            {
                const int sx0 = (int)floor(sx_f);
                const int sy0 = (int)floor(sy_f);
                const int sx1 = sx0 + 1;
                const int sy1 = sy0 + 1;
                const double fx = sx_f - (double)sx0;
                const double fy = sy_f - (double)sy0;

                auto safeA = [&](int px, int py) -> double {
                    // Return 0.0 jika out-of-bounds: piksel di luar canvas tidak ada.
                    if (px < 0 || px >= width || py < 0 || py >= height) return 0.0;
                    return src_base[py * src_stride + px].alpha / 32768.0;
                    };

                shiftedAlpha =
                    safeA(sx0, sy0) * (1.0 - fx) * (1.0 - fy) +
                    safeA(sx1, sy0) * fx * (1.0 - fy) +
                    safeA(sx0, sy1) * (1.0 - fx) * fy +
                    safeA(sx1, sy1) * fx * fy;
            }

            double invertedFill = 1.0 - shiftedAlpha;
            double mattedFill = invertedFill < origAlpha ? invertedFill : origAlpha;
            double rimAlpha = mattedFill * opacity;

            const double invRim = 1.0 - rimAlpha;
            double outR = sp.red * invRim + rimR_n * 32768.0 * rimAlpha;
            double outG = sp.green * invRim + rimG_n * 32768.0 * rimAlpha;
            double outB = sp.blue * invRim + rimB_n * 32768.0 * rimAlpha;

            dp.red = clamp32768((int)outR);
            dp.green = clamp32768((int)outG);
            dp.blue = clamp32768((int)outB);
            dp.alpha = sp.alpha;
        }
    }

    return PF_Err_NONE;
}

// ─────────────────────────────────────────────────────────────────────────────
// Render dispatcher
// ─────────────────────────────────────────────────────────────────────────────

static PF_Err Render(
    PF_InData* in_data,
    PF_OutData* out_data,
    PF_ParamDef* params[],
    PF_LayerDef* output)
{
    PF_Err       err = PF_Err_NONE;
    PF_LayerDef* input = &params[RIM_INPUT]->u.ld;

    RimLightInfo info;
    AEFX_CLR_STRUCT(info);

    info.rim_color = params[RIM_COLOR]->u.cd.value;
    info.rim_size = params[RIM_SIZE]->u.fs_d.value;
    info.rim_opacity = params[RIM_OPACITY]->u.fs_d.value;
    info.rim_angle = params[RIM_ANGLE]->u.ad.value / 65536.0;

    if (PF_WORLD_IS_DEEP(output)) {
        err = RimRender16(in_data, input, output, info);
    }
    else {
        err = RimRender8(in_data, input, output, info);
    }

    return err;
}

// ─────────────────────────────────────────────────────────────────────────────
// PreRender
//
// Kita perlu sample alpha di (x - dx, y - dy) — bisa jatuh di luar tile.
// Solusi: minta AE suplai input yang lebih besar dari output tile sebesar
// ceil(rim_size) ke semua sisi (checkout_rect di-expand), sehingga
// safeA tidak pernah keluar dari data yang disediakan AE.
// ─────────────────────────────────────────────────────────────────────────────

static PF_Err PreRender(
    PF_InData* in_data,
    PF_OutData* out_data,
    PF_PreRenderExtra* extra)
{
    PF_Err err = PF_Err_NONE;

    // Baca rim_size dari parameter
    PF_ParamDef rimSizeParam;
    AEFX_CLR_STRUCT(rimSizeParam);
    ERR(PF_CHECKOUT_PARAM(in_data, RIM_SIZE, in_data->current_time,
        in_data->time_step, in_data->time_scale, &rimSizeParam));

    const A_long pad = err ? 64 :
        static_cast<A_long>(ceil(rimSizeParam.u.fs_d.value)) + 2; // +2 untuk bilinear margin

    PF_CHECKIN_PARAM(in_data, &rimSizeParam);

    // Output rect: sama dengan yang diminta AE (tile ini)
    extra->output->result_rect = extra->input->output_request.rect;
    extra->output->max_result_rect = extra->input->output_request.rect;
    extra->output->solid = FALSE;
    extra->output->pre_render_data = NULL;

    // Checkout input yang lebih besar: expand ke semua sisi sebesar pad
    PF_RenderRequest req = extra->input->output_request;
    req.rect.left -= pad;
    req.rect.top -= pad;
    req.rect.right += pad;
    req.rect.bottom += pad;
    req.preserve_rgb_of_zero_alpha = FALSE;

    // checkout_layer argumen ke-8 adalah PF_CheckoutResult*, bukan PF_LRect*
    PF_CheckoutResult checkout_result;
    AEFX_CLR_STRUCT(checkout_result);

    ERR(extra->cb->checkout_layer(in_data->effect_ref,
        RIM_INPUT,
        RIM_INPUT,
        &req,
        in_data->current_time,
        in_data->time_step,
        in_data->time_scale,
        &checkout_result));
    // result_rect dan max_result_rect sudah di-set ke tile output di atas.

    return err;
}

// ─────────────────────────────────────────────────────────────────────────────
// SmartRender — dipanggil saat full render (SUPPORTS_SMART_RENDER aktif)
// Input layer sudah di-checkout oleh PreRender dengan rect yang di-expand.
// ─────────────────────────────────────────────────────────────────────────────

static PF_Err SmartRender(
    PF_InData* in_data,
    PF_OutData* out_data,
    PF_SmartRenderExtra* extra)
{
    PF_Err err = PF_Err_NONE;

    PF_EffectWorld* input_world = NULL;
    PF_EffectWorld* output_world = NULL;

    ERR(extra->cb->checkout_layer_pixels(in_data->effect_ref, RIM_INPUT, &input_world));
    ERR(extra->cb->checkout_output(in_data->effect_ref, &output_world));

    if (!err && input_world && output_world) {
        RimLightInfo info;
        AEFX_CLR_STRUCT(info);

        PF_ParamDef colorParam, sizeParam, opacityParam, angleParam;
        AEFX_CLR_STRUCT(colorParam);
        AEFX_CLR_STRUCT(sizeParam);
        AEFX_CLR_STRUCT(opacityParam);
        AEFX_CLR_STRUCT(angleParam);

        ERR(PF_CHECKOUT_PARAM(in_data, RIM_COLOR, in_data->current_time, in_data->time_step, in_data->time_scale, &colorParam));
        ERR(PF_CHECKOUT_PARAM(in_data, RIM_SIZE, in_data->current_time, in_data->time_step, in_data->time_scale, &sizeParam));
        ERR(PF_CHECKOUT_PARAM(in_data, RIM_OPACITY, in_data->current_time, in_data->time_step, in_data->time_scale, &opacityParam));
        ERR(PF_CHECKOUT_PARAM(in_data, RIM_ANGLE, in_data->current_time, in_data->time_step, in_data->time_scale, &angleParam));

        if (!err) {
            info.rim_color = colorParam.u.cd.value;
            info.rim_size = sizeParam.u.fs_d.value;
            info.rim_opacity = opacityParam.u.fs_d.value;
            info.rim_angle = angleParam.u.ad.value / 65536.0;

            // ----------------------------------------------------------------
            // Coordinate mapping: output pixel (x,y) -> input buffer (ix,iy)
            //
            // origin_x/y in AE SmartRender = comp-space coordinates (top-left
            // of each buffer in composition space). The difference gives how
            // many pixels output (0,0) is offset inside the input buffer.
            //
            //   ix = x + (output->origin_x - input->origin_x)
            //   iy = y + (output->origin_y - input->origin_y)
            //
            // This is stable even when layer size != comp size because both
            // origins are in the same comp-space coordinate system.
            //
            // Downsample fix: rim_size is in full-resolution pixels.
            // At lower quality, AE scales all world coordinates, so dx/dy
            // must also be scaled to match the buffer resolution.
            // ----------------------------------------------------------------
            const double ds_x = (double)in_data->downsample_x.num / (double)in_data->downsample_x.den;
            const double ds_y = (double)in_data->downsample_y.num / (double)in_data->downsample_y.den;

            const A_long off_x = output_world->origin_x - input_world->origin_x;
            const A_long off_y = output_world->origin_y - input_world->origin_y;

            const double angle_rad = info.rim_angle * 3.14159265358979323846 / 180.0;
            const double dx = cos(angle_rad) * info.rim_size * ds_x;
            const double dy = -sin(angle_rad) * info.rim_size * ds_y;
            const double opacity = info.rim_opacity / 100.0;

            if (PF_WORLD_IS_DEEP(output_world)) {
                const A_long out_w = output_world->width;
                const A_long out_h = output_world->height;
                const A_long in_w = input_world->width;
                const A_long in_h = input_world->height;
                const A_long src_stride = input_world->rowbytes / sizeof(PF_Pixel16);
                const A_long dst_stride = output_world->rowbytes / sizeof(PF_Pixel16);
                const PF_Pixel16* src_base = reinterpret_cast<const PF_Pixel16*>(input_world->data);
                PF_Pixel16* dst_base = reinterpret_cast<PF_Pixel16*>(output_world->data);

                const double rimR_n = info.rim_color.red / 255.0;
                const double rimG_n = info.rim_color.green / 255.0;
                const double rimB_n = info.rim_color.blue / 255.0;

                for (A_long y = 0; y < out_h; ++y) {
                    for (A_long x = 0; x < out_w; ++x) {
                        const A_long ix = x + off_x;
                        const A_long iy = y + off_y;

                        PF_Pixel16& dp = dst_base[y * dst_stride + x];
                        if (ix < 0 || ix >= in_w || iy < 0 || iy >= in_h) {
                            dp.red = dp.green = dp.blue = dp.alpha = 0;
                            continue;
                        }

                        const PF_Pixel16& sp = src_base[iy * src_stride + ix];
                        const double origAlpha = sp.alpha / 32768.0;

                        const double sx_f = (double)ix - dx;
                        const double sy_f = (double)iy - dy;
                        const int sx0 = (int)floor(sx_f);
                        const int sy0 = (int)floor(sy_f);
                        const double fx = sx_f - sx0;
                        const double fy = sy_f - sy0;

                        auto safeA = [&](int px, int py) -> double {
                            if (px < 0 || px >= in_w || py < 0 || py >= in_h) return 0.0;
                            return src_base[py * src_stride + px].alpha / 32768.0;
                            };

                        const double shiftedAlpha =
                            safeA(sx0, sy0) * (1.0 - fx) * (1.0 - fy) +
                            safeA(sx0 + 1, sy0) * fx * (1.0 - fy) +
                            safeA(sx0, sy0 + 1) * (1.0 - fx) * fy +
                            safeA(sx0 + 1, sy0 + 1) * fx * fy;

                        const double invertedFill = 1.0 - shiftedAlpha;
                        const double mattedFill = invertedFill < origAlpha ? invertedFill : origAlpha;
                        const double rimAlpha = mattedFill * opacity;
                        const double invRim = 1.0 - rimAlpha;

                        dp.red = clamp32768((int)(sp.red * invRim + rimR_n * 32768.0 * rimAlpha));
                        dp.green = clamp32768((int)(sp.green * invRim + rimG_n * 32768.0 * rimAlpha));
                        dp.blue = clamp32768((int)(sp.blue * invRim + rimB_n * 32768.0 * rimAlpha));
                        dp.alpha = sp.alpha;
                    }
                }
            }
            else {
                const A_long out_w = output_world->width;
                const A_long out_h = output_world->height;
                const A_long in_w = input_world->width;
                const A_long in_h = input_world->height;
                const A_long src_stride = input_world->rowbytes / sizeof(PF_Pixel8);
                const A_long dst_stride = output_world->rowbytes / sizeof(PF_Pixel8);
                const PF_Pixel8* src_base = reinterpret_cast<const PF_Pixel8*>(input_world->data);
                PF_Pixel8* dst_base = reinterpret_cast<PF_Pixel8*>(output_world->data);

                const double rimR_n = info.rim_color.red / 255.0;
                const double rimG_n = info.rim_color.green / 255.0;
                const double rimB_n = info.rim_color.blue / 255.0;

                for (A_long y = 0; y < out_h; ++y) {
                    for (A_long x = 0; x < out_w; ++x) {
                        const A_long ix = x + off_x;
                        const A_long iy = y + off_y;

                        PF_Pixel8& dp = dst_base[y * dst_stride + x];
                        if (ix < 0 || ix >= in_w || iy < 0 || iy >= in_h) {
                            dp.red = dp.green = dp.blue = dp.alpha = 0;
                            continue;
                        }

                        const PF_Pixel8& sp = src_base[iy * src_stride + ix];
                        const double origAlpha = sp.alpha / 255.0;

                        const double sx_f = (double)ix - dx;
                        const double sy_f = (double)iy - dy;
                        const int sx0 = (int)floor(sx_f);
                        const int sy0 = (int)floor(sy_f);
                        const double fx = sx_f - sx0;
                        const double fy = sy_f - sy0;

                        auto safeA = [&](int px, int py) -> double {
                            if (px < 0 || px >= in_w || py < 0 || py >= in_h) return 0.0;
                            return src_base[py * src_stride + px].alpha / 255.0;
                            };

                        const double shiftedAlpha =
                            safeA(sx0, sy0) * (1.0 - fx) * (1.0 - fy) +
                            safeA(sx0 + 1, sy0) * fx * (1.0 - fy) +
                            safeA(sx0, sy0 + 1) * (1.0 - fx) * fy +
                            safeA(sx0 + 1, sy0 + 1) * fx * fy;

                        const double invertedFill = 1.0 - shiftedAlpha;
                        const double mattedFill = invertedFill < origAlpha ? invertedFill : origAlpha;
                        const double rimAlpha = mattedFill * opacity;
                        const double invRim = 1.0 - rimAlpha;

                        dp.red = clamp255((int)(sp.red * invRim + rimR_n * 255.0 * rimAlpha));
                        dp.green = clamp255((int)(sp.green * invRim + rimG_n * 255.0 * rimAlpha));
                        dp.blue = clamp255((int)(sp.blue * invRim + rimB_n * 255.0 * rimAlpha));
                        dp.alpha = sp.alpha;
                    }
                }
            }
        }

        PF_CHECKIN_PARAM(in_data, &colorParam);
        PF_CHECKIN_PARAM(in_data, &sizeParam);
        PF_CHECKIN_PARAM(in_data, &opacityParam);
        PF_CHECKIN_PARAM(in_data, &angleParam);
    }

    if (input_world) extra->cb->checkin_layer_pixels(in_data->effect_ref, RIM_INPUT);
    // output world tidak perlu di-checkin

    return err;
}

// -----------------------------------------------------------------------------

extern "C" DllExport PF_Err EffectMain(
    PF_Cmd       cmd,
    PF_InData* in_data,
    PF_OutData* out_data,
    PF_ParamDef* params[],
    PF_LayerDef* output,
    void* extra)
{
    PF_Err err = PF_Err_NONE;
    try {
        switch (cmd) {
        case PF_Cmd_ABOUT:
            err = About(in_data, out_data, params, output);       break;
        case PF_Cmd_GLOBAL_SETUP:
            err = GlobalSetup(in_data, out_data, params, output); break;
        case PF_Cmd_PARAMS_SETUP:
            err = ParamsSetup(in_data, out_data, params, output); break;
        case PF_Cmd_RENDER:
            err = Render(in_data, out_data, params, output);      break;
        case PF_Cmd_SMART_PRE_RENDER:
            err = PreRender(in_data, out_data,
                reinterpret_cast<PF_PreRenderExtra*>(extra));     break;
        case PF_Cmd_SMART_RENDER:
            err = SmartRender(in_data, out_data,
                reinterpret_cast<PF_SmartRenderExtra*>(extra));   break;
        default: break;
        }
    }
    catch (PF_Err& thrown) { err = thrown; }
    return err;
}