#include "RimLight.h"

typedef struct {
    A_u_long index;
    A_char   str[256];
} TableString;

TableString g_strs[StrID_NUMTYPES] = {
    { StrID_NONE,                   "" },
    { StrID_Name,                   "RimLight" },
    { StrID_Description,            "Directional rim light using offset-fill alpha matte." },

    { StrID_RimColor_Param_Name,    "Color" },
    { StrID_RimSize_Param_Name,     "Size" },
    { StrID_RimOpacity_Param_Name,  "Opacity" },
    { StrID_RimAngle_Param_Name,    "Angle" },
    { StrID_RimSoftness_Param_Name, "Softness" },
    { StrID_RimBlendMode_Param_Name,"Blend Mode" },
};

char* GetStringPtr(int strNum)
{
    return g_strs[strNum].str;
}