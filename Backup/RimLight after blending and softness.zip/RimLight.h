#pragma once

#ifndef RIMLIGHT_H
#define RIMLIGHT_H

#include "AEConfig.h"
#include "entry.h"
#include "AE_Effect.h"
#include "AE_EffectCB.h"
#include "AE_Macros.h"
#include "AE_EffectCBSuites.h"
#include "AE_GeneralPlug.h"
#include "AEGP_SuiteHandler.h"
#include "String_Utils.h"
#include "Param_Utils.h"

#include <math.h>

// ─────────────────────────────────────────────────────────────────────────────
// Version
// ─────────────────────────────────────────────────────────────────────────────
#define MAJOR_VERSION    1
#define MINOR_VERSION    0
#define BUG_VERSION      0
#define STAGE_VERSION    PF_Stage_DEVELOP
#define BUILD_VERSION    1

// ─────────────────────────────────────────────────────────────────────────────
// Parameter indices
// ─────────────────────────────────────────────────────────────────────────────
enum {
    RIM_INPUT = 0,  // layer input (always index 0)
    RIM_COLOR,
    RIM_SIZE,
    RIM_OPACITY,
    RIM_ANGLE,
    RIM_SOFTNESS,
    RIM_BLEND_MODE,

    RIM_NUM_PARAMS
};

// Disk IDs (must be unique and stable — never change after shipping)
enum {
    RIM_COLOR_DISK_ID = 1,
    RIM_SIZE_DISK_ID,
    RIM_OPACITY_DISK_ID,
    RIM_ANGLE_DISK_ID,
    RIM_SOFTNESS_DISK_ID,
    RIM_BLEND_MODE_DISK_ID,
};

// ─────────────────────────────────────────────────────────────────────────────
// Parameter ranges & defaults
// ─────────────────────────────────────────────────────────────────────────────

// Size (distance offset in pixels)
#define RIM_SIZE_MIN    0.0
#define RIM_SIZE_MAX    500.0
#define RIM_SIZE_DFLT   10.0

// Opacity (0–100 %)
#define RIM_OPACITY_MIN  0.0
#define RIM_OPACITY_MAX  100.0
#define RIM_OPACITY_DFLT 100.0

// Angle default: 180 degrees → cahaya dari atas → rim di atas layer
#define RIM_ANGLE_DFLT   180

// Softness (Gaussian blur radius on rim mask, in pixels)
#define RIM_SOFTNESS_MIN   0.0
#define RIM_SOFTNESS_MAX   100.0
#define RIM_SOFTNESS_DFLT  0.0

// Blend Mode choices
#define RIM_BLEND_NORMAL   0
#define RIM_BLEND_ADD      1
#define RIM_BLEND_SCREEN   2
#define RIM_BLEND_DFLT     RIM_BLEND_NORMAL

// ─────────────────────────────────────────────────────────────────────────────
// String IDs (must match RimLight_Strings.h / .cpp)
// ─────────────────────────────────────────────────────────────────────────────
enum {
    StrID_NONE,
    StrID_Name,
    StrID_Description,
    StrID_RimColor_Param_Name,
    StrID_RimSize_Param_Name,
    StrID_RimOpacity_Param_Name,
    StrID_RimAngle_Param_Name,
    StrID_RimSoftness_Param_Name,
    StrID_RimBlendMode_Param_Name,
    StrID_NUMTYPES
};

// ─────────────────────────────────────────────────────────────────────────────
// Info struct passed to render functions
// ─────────────────────────────────────────────────────────────────────────────
typedef struct {
    PF_Pixel    rim_color;      // RGBA warna rim (red/green/blue 0–255)
    double      rim_size;       // offset distance dalam pixel
    double      rim_opacity;    // 0–100
    double      rim_angle;      // derajat (sudah dikonversi dari AE fixed-point)
    double      rim_softness;   // Gaussian blur radius pada rim mask (pixel)
    A_long      rim_blend_mode; // 0=Normal, 1=Add, 2=Screen
} RimLightInfo;

// ─────────────────────────────────────────────────────────────────────────────
// Entry point
// ─────────────────────────────────────────────────────────────────────────────
extern "C" {
    DllExport PF_Err EffectMain(
        PF_Cmd       cmd,
        PF_InData* in_data,
        PF_OutData* out_data,
        PF_ParamDef* params[],
        PF_LayerDef* output,
        void* extra);
}

#endif // RIMLIGHT_H